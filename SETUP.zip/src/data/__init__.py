"""Data pipeline modules for fetching and processing market data."""

