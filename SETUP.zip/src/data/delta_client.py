"""Delta Exchange API client for fetching market data."""

import hashlib
import hmac
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional

import pandas as pd
import requests
from requests.exceptions import RequestException

from src.core.config import settings
from src.core.logger import logger


class DeltaExchangeClient:
    """Client for interacting with Delta Exchange API."""
    
    def __init__(self):
        self.api_key = settings.delta_api_key
        self.api_secret = settings.delta_api_secret
        self.base_url = settings.delta_api_url
        self.session = requests.Session()
        
    def _generate_signature(self, method: str, endpoint: str, payload: str = "") -> str:
        """Generate HMAC signature for authenticated requests."""
        timestamp = str(int(time.time()))
        signature_data = method + timestamp + endpoint + payload
        signature = hmac.new(
            self.api_secret.encode(),
            signature_data.encode(),
            hashlib.sha256
        ).hexdigest()
        return signature, timestamp
    
    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        authenticated: bool = False
    ) -> Dict:
        """Make HTTP request to Delta Exchange API."""
        url = f"{self.base_url}{endpoint}"
        headers = {"Content-Type": "application/json"}
        
        if authenticated:
            payload = ""
            signature, timestamp = self._generate_signature(method, endpoint, payload)
            headers.update({
                "api-key": self.api_key,
                "signature": signature,
                "timestamp": timestamp
            })
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                params=params,
                headers=headers,
                timeout=10
            )
            response.raise_for_status()
            return response.json()
        except RequestException as e:
            logger.error("API request failed", error=str(e), endpoint=endpoint)
            raise
    
    def get_ohlc_candles(
        self,
        symbol: str,
        resolution: str,
        start: Optional[datetime] = None,
        end: Optional[datetime] = None,
        limit: int = 500
    ) -> pd.DataFrame:
        """Fetch OHLC candlestick data.
        
        Args:
            symbol: Trading symbol (e.g., 'BTCUSDT')
            resolution: Candle resolution ('1', '3', '5', '15', '30', '60', '120', '240', '1D')
            start: Start datetime
            end: End datetime
            limit: Maximum number of candles to fetch
            
        Returns:
            DataFrame with OHLC data
        """
        # Convert timeframe format (15m -> 15, 1h -> 60, etc.)
        resolution_map = {
            '1m': '1', '3m': '3', '5m': '5', '15m': '15', '30m': '30',
            '1h': '60', '2h': '120', '4h': '240', '6h': '360',
            '1d': '1D', '1D': '1D'
        }
        resolution = resolution_map.get(resolution, resolution)
        
        params = {
            'resolution': resolution,
            'symbol': symbol,
        }
        
        if start:
            params['start'] = int(start.timestamp())
        if end:
            params['end'] = int(end.timestamp())
        else:
            params['end'] = int(time.time())
        
        if not start:
            # Default to last 'limit' candles
            if resolution == '1D':
                start = datetime.utcnow() - timedelta(days=limit)
            else:
                minutes = int(resolution) if resolution.isdigit() else 1440
                start = datetime.utcnow() - timedelta(minutes=minutes * limit)
            params['start'] = int(start.timestamp())
        
        try:
            endpoint = "/v2/history/candles"
            response = self._make_request("GET", endpoint, params=params)
            
            if not response.get('success') or not response.get('result'):
                logger.warning("No candle data returned", symbol=symbol, resolution=resolution)
                return pd.DataFrame()
            
            candles = response['result']
            
            # Convert to DataFrame
            df = pd.DataFrame(candles)
            
            if df.empty:
                return df
            
            # Rename columns
            column_map = {
                'time': 'timestamp',
                'open': 'open',
                'high': 'high',
                'low': 'low',
                'close': 'close',
                'volume': 'volume'
            }
            df = df.rename(columns=column_map)
            
            # Convert timestamp to datetime
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
            
            # Add symbol and timeframe
            df['symbol'] = symbol
            df['timeframe'] = resolution
            
            # Select and order columns
            df = df[['timestamp', 'symbol', 'timeframe', 'open', 'high', 'low', 'close', 'volume']]
            
            # Sort by timestamp
            df = df.sort_values('timestamp').reset_index(drop=True)
            
            logger.info(
                "Fetched candle data",
                symbol=symbol,
                resolution=resolution,
                count=len(df),
                start=df['timestamp'].min(),
                end=df['timestamp'].max()
            )
            
            return df
            
        except Exception as e:
            logger.error("Failed to fetch candles", error=str(e), symbol=symbol, resolution=resolution)
            return pd.DataFrame()
    
    def get_ticker(self, symbol: str) -> Dict:
        """Get current ticker data for a symbol.
        
        Args:
            symbol: Trading symbol
            
        Returns:
            Ticker data dictionary
        """
        try:
            endpoint = f"/v2/tickers/{symbol}"
            response = self._make_request("GET", endpoint)
            
            if response.get('success') and response.get('result'):
                return response['result']
            return {}
            
        except Exception as e:
            logger.error("Failed to fetch ticker", error=str(e), symbol=symbol)
            return {}
    
    def get_account_balance(self) -> Dict:
        """Get account balance (for authenticated requests).
        
        Returns:
            Account balance data
        """
        try:
            endpoint = "/v2/wallet/balances"
            response = self._make_request("GET", endpoint, authenticated=True)
            
            if response.get('success') and response.get('result'):
                return response['result']
            return {}
            
        except Exception as e:
            logger.error("Failed to fetch account balance", error=str(e))
            return {}

