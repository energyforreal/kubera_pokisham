"""Kubera Pokisham AI Trading Agent."""

__version__ = "1.0.0"

